KOSHUD
Source  here: https://github.com/FuzzyMeepTWO/koshud
Tutorial Video Here: https://youtu.be/_Uq7atiHO7A
It is recommended that you set the setting "Start on the Archive" to enabled, as the script is too big for some KOS cores
This setting can be fond under "KOS" when accessing the settings menu from the space center main screen.


commands:

run "0:boot/pid.ks".